/**
 * Author: Jason Allen
 * GTID: 903535932
 * GT Email: jallen358@gatech.edu
 */

#pragma once

int main(int argc, char *argv[]);
